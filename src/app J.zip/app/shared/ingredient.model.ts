export class Ingredient{
    public name: string;
    public amount: number;

    constructor(name,amount){
        this.name = name;
        this.amount = amount;
    }
}